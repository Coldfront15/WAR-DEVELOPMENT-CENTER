// Name of your mod
name = "WDC- Department of War";
description = "War Development Center, Department of War";
// Picture displayed from the expansions menu/ Optimal size is 2048x1024, other sizes work too
picture = "large.paa"; 
// Display next to the item added by the mod
logoSmall = "089_ca.paa";
// Logo displayed in the main menu
logo = "089_ca.paa";
// When the mouse is over, in the main menu
logoOver = "089_jellwick_ca.paa";
action = "https://101aa.us";
tooltipOwned = "i stole this from simc";
tooltip = "budget simc";	
author = "kaldfront15. + Simcardo & co.";
// dlcColor[] = {0.23, 0.39, 0.30, 1};
overview = "errrm";
overviewText = "what the";
overviewFootnote = "sigma";
overviewPicture = "large.paa";